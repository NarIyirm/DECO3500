import admin from "firebase-admin";

const express = require('express');
const app = express();

// 加载 Firebase 凭据 JSON 文件
const serviceAccount = require('../ppl-cpl-firebase-adminsdk-by5rp-fcdf1d879e.json');

// 初始化 Firebase Admin SDK
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

// 使用 Express 解析 JSON 请求体
app.use(express.json());

// 处理来自前端的活动数据
app.post('/add-activity', async (req, res) => {
    const { activityData } = req.body;

    try {
        // 将数据存储到 Firestore
        await db.collection('activities').add(activityData);
        res.status(200).json({ message: 'Activity added successfully!' });
    } catch (error) {
        console.error('Error adding activity:', error);
        res.status(500).json({ message: 'Failed to add activity' });
    }
});

module.exports = app;
